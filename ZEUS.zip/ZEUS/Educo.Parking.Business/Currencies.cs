﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Educo.Parking.Business
{
    public enum Currencies
    {
        BYN,
        USD
    }
}
