﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Educo.Parking.Business
{
    public class Money
    {
        public decimal Value { get; set; }
        public Currencies Currency { get; set; }
    }
}
