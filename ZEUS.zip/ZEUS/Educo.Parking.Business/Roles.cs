﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Educo.Parking.Business
{
    public enum Roles
    {
        Administrator,
        Manager,
        User,
        
    }
}
