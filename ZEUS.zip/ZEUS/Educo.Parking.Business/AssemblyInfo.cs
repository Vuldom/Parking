﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Educo.Parking.Business.Tests")] //для доступа проекта бизнес логики в тестах