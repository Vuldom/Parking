﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Educo.Parking.Business
{
    public class IncorrectDateTimeException : Exception
    {
        public IncorrectDateTimeException() { }

    }
}
