# materialize-social
Social Login Buttons for MaterializeCSS

How to install
-------------

```
npm install --save materialize-social
```


```
bower install --save materialize-social
```


How to use
--------

Check out this site [usage](https://terrymooreii.github.io/materialize-social/)
