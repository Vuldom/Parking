﻿using Microsoft.AspNetCore.Identity;

namespace Educo.Parking.Data
{
    public class ApplicationRole:IdentityRole
    {

    }
}
